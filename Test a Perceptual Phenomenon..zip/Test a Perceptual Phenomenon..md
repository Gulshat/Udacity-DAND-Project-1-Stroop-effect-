
# Project 1.  Stroop effect.

*Author: Gulshat Badretdinova*


In a Stroop task, participants are presented with a list of words, with each word displayed in a color of ink. The participant’s task is to say out loud the color of the ink in which the word is printed. The task has two conditions: a congruent words condition, and an incongruent words condition. In the congruent words condition, the words being displayed are color words whose names match the colors in which they are printed: for example RED,
BLUE. In the incongruent words condition, the words displayed are color words whose names do not match the colors in which they are printed: for
example PURPLE, ORANGE. In each case, we measure the time it takes to name the ink colors in equally­sized lists. Each participant will go through
and record a time from each condition.


```python
# Add image
from IPython.display import Image
path = "/Users/gulsat/Desktop/statistics/P1/"
Image(filename = path + "word_set.png")
```




![png](output_3_0.png)




```python
%matplotlib inline
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import math

location = r"/Users/gulsat/Desktop/statistics/P1/stroopdata.csv"
dataSchema = pd.read_csv(location)
dataSchema["Participant ID"] = dataSchema.index + 1 #Add participant ID
dataSchema
```




<div>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Congruent</th>
      <th>Incongruent</th>
      <th>Participant ID</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>12.079</td>
      <td>19.278</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>16.791</td>
      <td>18.741</td>
      <td>2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>9.564</td>
      <td>21.214</td>
      <td>3</td>
    </tr>
    <tr>
      <th>3</th>
      <td>8.630</td>
      <td>15.687</td>
      <td>4</td>
    </tr>
    <tr>
      <th>4</th>
      <td>14.669</td>
      <td>22.803</td>
      <td>5</td>
    </tr>
    <tr>
      <th>5</th>
      <td>12.238</td>
      <td>20.878</td>
      <td>6</td>
    </tr>
    <tr>
      <th>6</th>
      <td>14.692</td>
      <td>24.572</td>
      <td>7</td>
    </tr>
    <tr>
      <th>7</th>
      <td>8.987</td>
      <td>17.394</td>
      <td>8</td>
    </tr>
    <tr>
      <th>8</th>
      <td>9.401</td>
      <td>20.762</td>
      <td>9</td>
    </tr>
    <tr>
      <th>9</th>
      <td>14.480</td>
      <td>26.282</td>
      <td>10</td>
    </tr>
    <tr>
      <th>10</th>
      <td>22.328</td>
      <td>24.524</td>
      <td>11</td>
    </tr>
    <tr>
      <th>11</th>
      <td>15.298</td>
      <td>18.644</td>
      <td>12</td>
    </tr>
    <tr>
      <th>12</th>
      <td>15.073</td>
      <td>17.510</td>
      <td>13</td>
    </tr>
    <tr>
      <th>13</th>
      <td>16.929</td>
      <td>20.330</td>
      <td>14</td>
    </tr>
    <tr>
      <th>14</th>
      <td>18.200</td>
      <td>35.255</td>
      <td>15</td>
    </tr>
    <tr>
      <th>15</th>
      <td>12.130</td>
      <td>22.158</td>
      <td>16</td>
    </tr>
    <tr>
      <th>16</th>
      <td>18.495</td>
      <td>25.139</td>
      <td>17</td>
    </tr>
    <tr>
      <th>17</th>
      <td>10.639</td>
      <td>20.429</td>
      <td>18</td>
    </tr>
    <tr>
      <th>18</th>
      <td>11.344</td>
      <td>17.425</td>
      <td>19</td>
    </tr>
    <tr>
      <th>19</th>
      <td>12.369</td>
      <td>34.288</td>
      <td>20</td>
    </tr>
    <tr>
      <th>20</th>
      <td>12.944</td>
      <td>23.894</td>
      <td>21</td>
    </tr>
    <tr>
      <th>21</th>
      <td>14.233</td>
      <td>17.960</td>
      <td>22</td>
    </tr>
    <tr>
      <th>22</th>
      <td>19.710</td>
      <td>22.058</td>
      <td>23</td>
    </tr>
    <tr>
      <th>23</th>
      <td>16.004</td>
      <td>21.157</td>
      <td>24</td>
    </tr>
  </tbody>
</table>
</div>



### 1. Independent and dependent variable

- Independent - congruent words condition, incongruent words condition
- Dependent - Response Time in seconds

### 2. Dependent sample two-tailed t-test

The dependent samples two-tailed t-test is the appropriate methods for this tasks for these following reasons:

* We can compare two means from 2 samples for pre-test period and post-test period.
* The dataset doesn't include population μ and σ. We cann't conduct a z-test.

H0 - Null Hypothesis: ( μi - μc = 0 ) 
 There is no significant difference in the population average response time in viewing the congruent(c) words vs viewing the incongruent(i) words.

HA - Alternative Hypothesis: ( μi - μc ≠ 0 ) 
 There is a significant difference, positive or negative, in the population average response times.

### 3. Descriptive statistic.


```python
# Separate congruent and incongruent data

frame_congruent = dataSchema["Congruent"]
frame_icongruent = dataSchema["Incongruent"]
```

Report some descriptive statistics regarding this dataset. Include at least one measure of central tendency and at least one measure of variability.



```python
m_congruent = round(frame_congruent.mean(),2)
m_icongruent = round(frame_icongruent.mean(),2)
med_congruent = round(frame_congruent.median(),2)
med_icongruent = round(frame_icongruent.median(),2)
std_congruent = round(frame_congruent.std(),2)
std_icongruent = round(frame_icongruent.std(),2)
```

##### Central tendency measurement.


```python
print "Congruent mean: "
print m_congruent

print "Icongruent mean: "
print m_icongruent

print "Congruent median: "
print med_congruent

print "Icongruent median: "
print med_icongruent
```

    Congruent mean: 
    14.05
    Icongruent mean: 
    22.02
    Congruent median: 
    14.36
    Icongruent median: 
    21.02


##### Variability measurements


```python
print "Congruent standart deviation: "
print std_congruent

print "Icongruent standart deviation: "
print std_icongruent
```

    Congruent standart deviation: 
    3.56
    Icongruent standart deviation: 
    4.8


### 4. Data visualisation.


```python
dataSchema.plot(x = "Participant ID",
               kind = "box",
               vert = False,
               color = dict(boxes = "Red",
                           whiskers = "DarkGreen",
                           medians = "Black",
                           caps = "Blue")
               ).set_xlabel("Time Response (second)")
plt.show()
```


![png](output_19_0.png)


##### Observation:

Visually speaking, the box plot shows that the mean of incongruent response time may not be within the t-critical from congruent response time. Also, we can also see few outlier from "Incongruent" that could indicate the response time is significant higher if we take more sample size. 

### 5. Statistical test and result.

Confidence Level = 90%

α=0.1

t-critical value (2-sided test) -> from t-table 

df = 23

t-critical = +- 1.711



```python
# Calculate point estimate
estimate_p = round((m_icongruent - m_congruent),2)
print "Point estimate: "
print estimate_p
```

    Point estimate: 
    7.97



```python
# Calculate SD difference between Cougruent and Incongruent.
dataSchema["D"] = dataSchema["Incongruent"] - dataSchema["Congruent"]
dataSchema["D"]
sd = round((np.std(dataSchema["D"], ddof = 1, dtype=np.float64)),3)
print "SD: "
print sd
```

    SD: 
    4.865



```python
# Calculate t-statistic with n=24, point estimate = 7.97 and standart deviation
t = round(estimate_p/(sd/math.sqrt(24)),3)
print "t-statistic: "
print t
```

    t-statistic: 
    8.026


#### Result

t-statistic = 8.026 > t-critical = 1.714 by a significant amount.

We reject the Null Hypothesis which states that there is no significant differences between the population average completion time for the two different conditions.



